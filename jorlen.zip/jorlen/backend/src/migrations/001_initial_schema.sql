-- Users table for authentication and RBAC
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  phone VARCHAR(20),
  role VARCHAR(50) NOT NULL DEFAULT 'staff',
  is_active BOOLEAN DEFAULT true,
  last_login TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_email (email),
  INDEX idx_role (role),
  INDEX idx_is_active (is_active)
);

-- Organization/Customer Categories
CREATE TABLE IF NOT EXISTS customer_categories (
  id SERIAL PRIMARY KEY,
  name VARCHAR(50) UNIQUE NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Customers and Organizations
CREATE TABLE IF NOT EXISTS customers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  category VARCHAR(50) NOT NULL DEFAULT 'SME',
  email VARCHAR(255),
  phone VARCHAR(20),
  physical_address TEXT,
  city VARCHAR(100),
  country VARCHAR(100) DEFAULT 'Uganda',
  postal_code VARCHAR(20),
  contact_person_name VARCHAR(255),
  contact_person_phone VARCHAR(20),
  contact_person_email VARCHAR(255),
  tax_id VARCHAR(50),
  registration_number VARCHAR(100),
  is_active BOOLEAN DEFAULT true,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_email (email),
  INDEX idx_phone (phone),
  INDEX idx_category (category),
  INDEX idx_is_active (is_active)
);

-- Customers Attachments (contracts, IDs, SLAs)
CREATE TABLE IF NOT EXISTS customer_attachments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL,
  file_name VARCHAR(255) NOT NULL,
  file_path TEXT NOT NULL,
  file_type VARCHAR(50),
  file_size INT,
  attachment_type VARCHAR(50),
  uploaded_by UUID NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
  FOREIGN KEY (uploaded_by) REFERENCES users(id)
);

-- Service Subscriptions and Contracts
CREATE TABLE IF NOT EXISTS customer_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL,
  service_name VARCHAR(255) NOT NULL,
  description TEXT,
  billing_type VARCHAR(50) NOT NULL DEFAULT 'monthly',
  amount_ugx DECIMAL(15, 2) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE,
  is_active BOOLEAN DEFAULT true,
  auto_renew BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
  INDEX idx_customer_id (customer_id),
  INDEX idx_is_active (is_active)
);

-- Leads/Sales Pipeline
CREATE TABLE IF NOT EXISTS leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title VARCHAR(255) NOT NULL,
  company_name VARCHAR(255),
  contact_name VARCHAR(255) NOT NULL,
  contact_email VARCHAR(255),
  contact_phone VARCHAR(20),
  service_interested VARCHAR(255),
  estimated_value_ugx DECIMAL(15, 2),
  pipeline_stage VARCHAR(50) NOT NULL DEFAULT 'new-lead',
  source VARCHAR(100),
  assigned_to UUID,
  probability_percentage INT DEFAULT 0,
  expected_close_date DATE,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  closed_at TIMESTAMP,
  FOREIGN KEY (assigned_to) REFERENCES users(id),
  INDEX idx_pipeline_stage (pipeline_stage),
  INDEX idx_assigned_to (assigned_to),
  INDEX idx_source (source)
);

-- Lead Follow-ups and Activities
CREATE TABLE IF NOT EXISTS lead_activities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NOT NULL,
  activity_type VARCHAR(50) NOT NULL,
  description TEXT NOT NULL,
  scheduled_date TIMESTAMP,
  completed_date TIMESTAMP,
  created_by UUID NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE CASCADE,
  FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Quotations
CREATE TABLE IF NOT EXISTS quotations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID,
  customer_id UUID,
  quotation_number VARCHAR(50) UNIQUE NOT NULL,
  description TEXT,
  total_amount_ugx DECIMAL(15, 2) NOT NULL,
  currency VARCHAR(3) DEFAULT 'UGX',
  valid_until DATE,
  status VARCHAR(50) NOT NULL DEFAULT 'draft',
  created_by UUID NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (lead_id) REFERENCES leads(id),
  FOREIGN KEY (customer_id) REFERENCES customers(id),
  FOREIGN KEY (created_by) REFERENCES users(id),
  INDEX idx_status (status),
  INDEX idx_quotation_number (quotation_number)
);

-- Service Request/Support Tickets
CREATE TABLE IF NOT EXISTS support_tickets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_number VARCHAR(50) UNIQUE NOT NULL,
  customer_id UUID NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  issue_category VARCHAR(100) NOT NULL,
  priority VARCHAR(20) NOT NULL DEFAULT 'medium',
  status VARCHAR(50) NOT NULL DEFAULT 'open',
  assigned_to UUID,
  sla_response_hours INT,
  sla_resolution_hours INT,
  responded_at TIMESTAMP,
  resolved_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_by UUID NOT NULL,
  FOREIGN KEY (customer_id) REFERENCES customers(id),
  FOREIGN KEY (assigned_to) REFERENCES users(id),
  FOREIGN KEY (created_by) REFERENCES users(id),
  INDEX idx_status (status),
  INDEX idx_priority (priority),
  INDEX idx_customer_id (customer_id),
  INDEX idx_assigned_to (assigned_to),
  INDEX idx_ticket_number (ticket_number)
);

-- Ticket Comments
CREATE TABLE IF NOT EXISTS ticket_comments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id UUID NOT NULL,
  comment_text TEXT NOT NULL,
  created_by UUID NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (ticket_id) REFERENCES support_tickets(id) ON DELETE CASCADE,
  FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Projects/Installations
CREATE TABLE IF NOT EXISTS projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_code VARCHAR(50) UNIQUE NOT NULL,
  customer_id UUID NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  project_type VARCHAR(100) NOT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'planning',
  start_date DATE NOT NULL,
  planned_end_date DATE,
  actual_end_date DATE,
  budget_ugx DECIMAL(15, 2),
  actual_cost_ugx DECIMAL(15, 2),
  assigned_engineer_id UUID,
  assigned_technician_ids TEXT,
  progress_percentage INT DEFAULT 0,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customers(id),
  FOREIGN KEY (assigned_engineer_id) REFERENCES users(id),
  INDEX idx_status (status),
  INDEX idx_customer_id (customer_id),
  INDEX idx_project_code (project_code)
);

-- Project Milestones
CREATE TABLE IF NOT EXISTS project_milestones (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  planned_date DATE NOT NULL,
  actual_date DATE,
  status VARCHAR(50) NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

-- Project Attachments (diagrams, photos, configs)
CREATE TABLE IF NOT EXISTS project_attachments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL,
  file_name VARCHAR(255) NOT NULL,
  file_path TEXT NOT NULL,
  file_type VARCHAR(50),
  attachment_type VARCHAR(50),
  uploaded_by UUID NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (uploaded_by) REFERENCES users(id)
);

-- Invoices
CREATE TABLE IF NOT EXISTS invoices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_number VARCHAR(50) UNIQUE NOT NULL,
  customer_id UUID NOT NULL,
  project_id UUID,
  subscription_id UUID,
  invoice_type VARCHAR(50) NOT NULL DEFAULT 'standard',
  issue_date DATE NOT NULL,
  due_date DATE NOT NULL,
  total_amount_ugx DECIMAL(15, 2) NOT NULL,
  tax_amount_ugx DECIMAL(15, 2) DEFAULT 0,
  currency VARCHAR(3) DEFAULT 'UGX',
  status VARCHAR(50) NOT NULL DEFAULT 'draft',
  paid_amount_ugx DECIMAL(15, 2) DEFAULT 0,
  payment_status VARCHAR(50) NOT NULL DEFAULT 'unpaid',
  line_items JSONB,
  notes TEXT,
  created_by UUID NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customers(id),
  FOREIGN KEY (project_id) REFERENCES projects(id),
  FOREIGN KEY (subscription_id) REFERENCES customer_subscriptions(id),
  FOREIGN KEY (created_by) REFERENCES users(id),
  INDEX idx_status (status),
  INDEX idx_payment_status (payment_status),
  INDEX idx_customer_id (customer_id),
  INDEX idx_invoice_number (invoice_number)
);

-- Payments
CREATE TABLE IF NOT EXISTS payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id UUID NOT NULL,
  payment_date DATE NOT NULL,
  amount_ugx DECIMAL(15, 2) NOT NULL,
  payment_method VARCHAR(50) NOT NULL,
  reference_number VARCHAR(100),
  notes TEXT,
  received_by UUID NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (invoice_id) REFERENCES invoices(id),
  FOREIGN KEY (received_by) REFERENCES users(id),
  INDEX idx_invoice_id (invoice_id),
  INDEX idx_payment_date (payment_date)
);

-- Inventory/Equipment
CREATE TABLE IF NOT EXISTS inventory_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  item_code VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  category VARCHAR(100) NOT NULL,
  quantity_in_stock INT NOT NULL DEFAULT 0,
  reorder_level INT DEFAULT 10,
  unit_cost_ugx DECIMAL(15, 2),
  unit_selling_price_ugx DECIMAL(15, 2),
  supplier VARCHAR(255),
  supplier_contact VARCHAR(100),
  warranty_months INT,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_item_code (item_code),
  INDEX idx_category (category),
  INDEX idx_quantity_in_stock (quantity_in_stock)
);

-- Equipment Assignments to Projects/Customers
CREATE TABLE IF NOT EXISTS equipment_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  item_id UUID NOT NULL,
  customer_id UUID,
  project_id UUID,
  serial_number VARCHAR(100) UNIQUE,
  quantity INT NOT NULL DEFAULT 1,
  assignment_date DATE NOT NULL,
  end_date DATE,
  status VARCHAR(50) NOT NULL DEFAULT 'assigned',
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (item_id) REFERENCES inventory_items(id),
  FOREIGN KEY (customer_id) REFERENCES customers(id),
  FOREIGN KEY (project_id) REFERENCES projects(id)
);

-- Audit Logs
CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID,
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(100),
  entity_id UUID,
  description TEXT,
  old_values JSONB,
  new_values JSONB,
  ip_address VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  INDEX idx_user_id (user_id),
  INDEX idx_created_at (created_at),
  INDEX idx_entity_type (entity_type)
);

-- Sample Customer Categories
INSERT INTO customer_categories (name, description) VALUES
('SME', 'Small and Medium Enterprises'),
('Enterprise', 'Large Enterprise Organizations'),
('Government', 'Government and Public Institutions'),
('Residential', 'Residential/Home Users'),
('Educational', 'Educational Institutions'),
('Healthcare', 'Healthcare Facilities')
ON CONFLICT DO NOTHING;

-- Sample Roles
INSERT INTO users (email, password_hash, first_name, last_name, role) VALUES
('admin@jorlen.com', '$2b$10$admin_hash', 'Admin', 'User', 'administrator'),
('sales@jorlen.com', '$2b$10$sales_hash', 'Sales Agent', 'Jorlen', 'sales'),
('tech@jorlen.com', '$2b$10$tech_hash', 'Technician', 'Jorlen', 'technician'),
('finance@jorlen.com', '$2b$10$finance_hash', 'Finance Officer', 'Jorlen', 'finance'),
('manager@jorlen.com', '$2b$10$manager_hash', 'Manager', 'Jorlen', 'management')
ON CONFLICT DO NOTHING;
